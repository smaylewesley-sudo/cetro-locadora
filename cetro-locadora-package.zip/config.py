import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "muda_para_uma_chave_forte")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/cetrodb")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Backup / Google Drive
    GDRIVE_FOLDER_ID = os.environ.get("GDRIVE_FOLDER_ID", "")
    GOOGLE_CREDENTIALS_JSON = os.environ.get("GOOGLE_CREDENTIALS_JSON", "credentials.json")
    BACKUP_TIME_HOUR = int(os.environ.get("BACKUP_HOUR", "18"))  # 24h format
