from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class Role:
    ADMIN = "admin"
    ATENDENTE = "atendente"
    FINANCEIRO = "financeiro"
    VISUALIZADOR = "visualizador"

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(32), default=Role.ATENDENTE)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    cpf_cnpj = db.Column(db.String(50))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(120))
    cnh = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plate = db.Column(db.String(32), unique=True, nullable=False)
    brand = db.Column(db.String(120))
    model = db.Column(db.String(120))
    year = db.Column(db.Integer)
    color = db.Column(db.String(50))
    daily_rate = db.Column(db.Float, default=0.0)
    km_rate = db.Column(db.Float, default=0.0)
    current_km = db.Column(db.Integer, default=0)
    status = db.Column(db.String(32), default="available")  # available, rented, maintenance, reserved

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('client.id'), nullable=False)
    client = db.relationship('Client')
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    vehicle = db.relationship('Vehicle')
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    start_km = db.Column(db.Integer, default=0)
    end_km = db.Column(db.Integer)
    status = db.Column(db.String(32), default="pending")  # pending, confirmed, active, completed, canceled
    total_amount = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class FinancialEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20))  # entrada / saida
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    reservation_id = db.Column(db.Integer, db.ForeignKey('reservation.id'), nullable=True)
