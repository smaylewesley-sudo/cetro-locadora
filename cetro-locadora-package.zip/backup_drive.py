import os
import subprocess
import datetime
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

def upload_file_to_drive(credentials_json_path, folder_id, local_path, filename):
    creds = service_account.Credentials.from_service_account_file(credentials_json_path, scopes=["https://www.googleapis.com/auth/drive.file"])
    service = build('drive', 'v3', credentials=creds)
    media = MediaFileUpload(local_path, resumable=True)
    file_metadata = {'name': filename, 'parents': [folder_id]} if folder_id else {'name': filename}
    file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    return file.get('id')

def perform_backup_if_configured(app):
    try:
        folder = app.config.get("GDRIVE_FOLDER_ID")
        cred_path = app.config.get("GOOGLE_CREDENTIALS_JSON")
        if not folder or not os.path.exists(cred_path):
            app.logger.info("Google Drive backup: configuration missing, skipping")
            return
        # create dump file using pg_dump (assumes DATABASE_URL env)
        db_url = app.config.get("SQLALCHEMY_DATABASE_URI")
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        local_file = f"/tmp/cetro_backup_{timestamp}.sql"
        cmd = f"pg_dump \"{db_url}\" -Fc -f {local_file}"
        rc = subprocess.call(cmd, shell=True)
        if rc != 0:
            app.logger.error("pg_dump failed with code %s", rc)
            return
        filename = os.path.basename(local_file)
        file_id = upload_file_to_drive(cred_path, folder, local_file, filename)
        app.logger.info("Backup uploaded to Google Drive fileId=%s", file_id)
        try:
            os.remove(local_file)
        except:
            pass
    except Exception as e:
        app.logger.exception("Erro ao realizar backup: %s", e)
