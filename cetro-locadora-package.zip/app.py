import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort
from config import Config
from models import db, User, Client, Vehicle, Reservation, FinancialEntry, Role
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

# Scheduler for backups
from apscheduler.schedulers.background import BackgroundScheduler
from backup_drive import perform_backup_if_configured

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_default():
    db.create_all()
    # seed default user if not exist
    if not User.query.filter_by(username="cetro").first():
        u = User(username="cetro", password_hash=generate_password_hash("admin123"), role=Role.ADMIN)
        db.session.add(u)
        db.session.commit()

# ---------- Routes: Auth ----------
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","")
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for("locacoes"))
        flash("Credenciais inválidas", "danger")
    return render_template("login.html", title="Login - CETRO LOCADORA")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# ---------- Routes: Locações (tela inicial) ----------
@app.route("/")
@login_required
def locacoes():
    # list reservations - default view: open/pending/active first
    q = Reservation.query.order_by(Reservation.created_at.desc()).limit(200).all()
    vehicles = Vehicle.query.all()
    clients = Client.query.all()
    return render_template("locacoes.html", reservations=q, vehicles=vehicles, clients=clients, user=current_user)

@app.route("/reservations/create", methods=["POST"])
@login_required
def create_reservation():
    client_id = request.form.get("client_id")
    vehicle_id = request.form.get("vehicle_id")
    start_date = request.form.get("start_date")
    end_date = request.form.get("end_date")
    start_km = int(request.form.get("start_km") or 0)
    # simple validation
    if not client_id or not vehicle_id or not start_date or not end_date:
        flash("Campos obrigatórios faltando", "warning")
        return redirect(url_for("locacoes"))
    sd = datetime.fromisoformat(start_date)
    ed = datetime.fromisoformat(end_date)
    vehicle = Vehicle.query.get(int(vehicle_id))
    # calculate days
    days = max(1, (ed.date() - sd.date()).days or 1)
    total = days * (vehicle.daily_rate or 0)
    res = Reservation(client_id=int(client_id), vehicle_id=int(vehicle_id),
                      start_date=sd, end_date=ed, start_km=start_km, total_amount=total, status="pending")
    vehicle.status = "reserved"
    db.session.add(res)
    db.session.commit()
    flash("Reserva criada com sucesso", "success")
    return redirect(url_for("locacoes"))

@app.route("/reservations/<int:rid>/activate", methods=["POST"])
@login_required
def activate_reservation(rid):
    r = Reservation.query.get_or_404(rid)
    r.status = "active"
    r.vehicle.status = "rented"
    db.session.commit()
    flash("Locação iniciada", "success")
    return redirect(url_for("locacoes"))

@app.route("/reservations/<int:rid>/complete", methods=["POST"])
@login_required
def complete_reservation(rid):
    r = Reservation.query.get_or_404(rid)
    end_km = request.form.get("end_km")
    if end_km:
        r.end_km = int(end_km)
        # optionally compute amount for extra km
    r.status = "completed"
    r.vehicle.status = "available"
    db.session.commit()
    flash("Locação finalizada", "success")
    return redirect(url_for("locacoes"))

# ---------- Vehicles / Clients ----------
@app.route("/vehicles")
@login_required
def vehicles():
    items = Vehicle.query.order_by(Vehicle.brand).all()
    return render_template("veiculos.html", vehicles=items)

@app.route("/vehicles/create", methods=["POST"])
@login_required
def create_vehicle():
    plate = request.form.get("plate")
    brand = request.form.get("brand")
    model = request.form.get("model")
    year = int(request.form.get("year") or 0)
    daily = float(request.form.get("daily_rate") or 0)
    km_rate = float(request.form.get("km_rate") or 0)
    v = Vehicle(plate=plate, brand=brand, model=model, year=year, daily_rate=daily, km_rate=km_rate)
    db.session.add(v); db.session.commit()
    flash("Veículo cadastrado", "success")
    return redirect(url_for("vehicles"))

@app.route("/clients")
@login_required
def clients():
    items = Client.query.order_by(Client.name).all()
    return render_template("clientes.html", clients=items)

@app.route("/clients/create", methods=["POST"])
@login_required
def create_client():
    name = request.form.get("name")
    cpf = request.form.get("cpf_cnpj")
    phone = request.form.get("phone")
    c = Client(name=name, cpf_cnpj=cpf, phone=phone)
    db.session.add(c); db.session.commit()
    flash("Cliente cadastrado", "success")
    return redirect(url_for("clients"))

# ---------- Financial ----------
@app.route("/finance")
@login_required
def finance():
    entries = FinancialEntry.query.order_by(FinancialEntry.date.desc()).limit(200).all()
    return render_template("financeiro.html", entries=entries)

@app.route("/finance/create", methods=["POST"])
@login_required
def create_finance():
    t = request.form.get("type")
    amount = float(request.form.get("amount") or 0)
    desc = request.form.get("description")
    f = FinancialEntry(type=t, amount=amount, description=desc)
    db.session.add(f); db.session.commit()
    flash("Lançamento registrado", "success")
    return redirect(url_for("finance"))

# ---------- Contract PDF ----------
@app.route("/reservations/<int:rid>/contract.pdf")
@login_required
def contract_pdf(rid):
    res = Reservation.query.get_or_404(rid)
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    # header with logo (assumes backend/static/logo.png exists)
    logo_path = os.path.join(app.root_path, "static", "logo.png")
    try:
        if os.path.exists(logo_path):
            p.drawImage(logo_path, 40, height - 90, width=120, preserveAspectRatio=True, mask='auto')
    except Exception:
        pass
    p.setFont("Helvetica-Bold", 14)
    p.drawString(180, height - 50, "CONTRATO DE LOCAÇÃO DE VEÍCULO")
    p.setFont("Helvetica", 10)
    y = height - 120
    p.drawString(40, y, f"Reserva ID: {res.id}")
    p.drawString(40, y-14, f"Cliente: {res.client.name if res.client else '---'}")
    p.drawString(40, y-28, f"Veículo: {res.vehicle.brand} {res.vehicle.model} - {res.vehicle.plate}")
    p.drawString(40, y-42, f"Período: {res.start_date.date()} até {res.end_date.date()}")
    p.drawString(40, y-56, f"Valor estimado: R$ { (res.total_amount or 0):.2f }")
    # sample clauses
    p.drawString(40, y-90, "Cláusulas básicas:")
    p.setFont("Helvetica", 9)
    p.drawString(40, y-108, "1) O LOCATÁRIO deverá devolver o veículo nas mesmas condições.")
    p.drawString(40, y-124, "2) Multas e infrações são de responsabilidade do locatário.")
    # footer
    p.setFont("Helvetica", 9)
    p.drawString(40, 60, "Assinatura LOCADORA: ____________________      Assinatura LOCATÁRIO: ____________________")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"contrato_reserva_{res.id}.pdf", mimetype="application/pdf")

# ---------- Simple health ----------
@app.route("/health")
def health():
    return {"status":"ok"}

# ---------- Scheduler: backups ----------
scheduler = BackgroundScheduler()
scheduler.add_job(lambda: perform_backup_if_configured(app), 'cron', hour=app.config.get("BACKUP_TIME_HOUR",18))
scheduler.start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
